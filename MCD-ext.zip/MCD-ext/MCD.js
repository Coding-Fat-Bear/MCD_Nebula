define(['./dist/MCD'], (supernova) => supernova);
